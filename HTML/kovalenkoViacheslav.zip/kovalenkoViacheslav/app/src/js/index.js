{
  const carousel = document.getElementById("portfolio-carousel");
  const carouselOptions = carousel.querySelectorAll(".carousel__item");
  const currentSlide = carousel.querySelector(".carousel__slide");
  const toggleBtn = document.querySelector("#toggler");
  const navList = document.querySelector(".navigation__list");
  const articlesWrapper = document.querySelector(".site__articles-wrapper");
  const articleTemplate = document.querySelector("#article-template");
  const addArticleBtn = document.querySelector("#btn-add");
  const changeHeaderBtn = document.querySelector("#btn-header");
  const featuresElement = document.querySelectorAll(".feature");

  const carouselImages = [
    "./src/images/dest/img/img1.jpg",
    "./src/images/dest/img/img2.jpg",
    "./src/images/dest/img/img3.jpg",
    "./src/images/dest/img/img4.jpg",
    "./src/images/dest/img/img5.jpg",
    "./src/images/dest/img/img6.jpg",
  ];

  [...carouselOptions].forEach((opt, i) => {
    opt.addEventListener("click", toggleHandler.bind(null, i));
  });

  toggleBtn.addEventListener("click", togglerHandler);

  addArticleBtn.addEventListener("click", newArticleHandler);

  changeHeaderBtn.addEventListener("click", headersHandler);

  navList.addEventListener("click", togglerHandler);

  let headerIdx = 1;

  function headersHandler() {
    const featuresArr = [...featuresElement];
    const headerOptions = [
      "Short header",
      "Very very long and difficult to understand header",
    ];
    headerIdx === 1 ? (headerIdx = 0) : (headerIdx = 1);

    for (let i = 0; i < featuresArr.length; i++) {
      featuresArr[i].querySelector(".feature__header-title").innerText =
        headerOptions[headerIdx];
    }
  }

  function newArticleHandler() {
    const newArticle = articleTemplate.content.cloneNode(true);
    articlesWrapper.appendChild(newArticle);
  }

  function toggleHandler(i, evt) {
    const imgSrc = "url(" + carouselImages[i] + ")";
    currentSlide.style.backgroundImage = imgSrc;

    [...carouselOptions].forEach((opt) => {
      opt.classList.remove("carousel__item--current");
    });

    evt.target.closest("div").classList.add("carousel__item--current");
  }

  function togglerHandler() {
    navList.style.display == "none"
      ? (navList.style.display = "flex")
      : (navList.style.display = "none");
  }

  window.addEventListener("resize", () => {
    if (window.innerWidth > 769) {
      navList.style.display = "flex";
      navList.removeEventListener("click", togglerHandler);
    } else {
      navList.style.display = "none";
      navList.addEventListener("click", togglerHandler);
    }
  });
}
